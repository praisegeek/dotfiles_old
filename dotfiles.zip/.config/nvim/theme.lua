vim.cmd[[colorscheme tokyonight]]
